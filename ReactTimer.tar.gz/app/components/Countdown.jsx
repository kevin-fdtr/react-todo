var React = require('react');

var Countdown = React.createClass({
  render: function () {
    return (
      <div>
        <p>Render Countdown.jsx</p>
      </div>
    );
  }
});

module.exports = Countdown;
