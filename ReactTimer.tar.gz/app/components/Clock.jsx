var React = require('react');

var Clock = React.createClass({
    render: function () {
      return (
        <div>

        </div>
      );
    }
});

module.exports = Clock;
