var React = require('react');

var Timer = React.createClass({
  render: function () {
    return (
      <div>
        <p>Render Timer.jsx</p>
      </div>
    );
  }
});

module.exports = Timer;
